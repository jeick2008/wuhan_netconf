var messages__xml_8h =
[
    [ "ncxml_filter_new", "d9/de5/messages__xml_8h.html#gac05e048345a6130490bdbdde8e52a845", null ],
    [ "ncxml_reply_build", "d9/de5/messages__xml_8h.html#gaaaf53b5a839be6935059fdf2818a5a42", null ],
    [ "ncxml_reply_data", "d9/de5/messages__xml_8h.html#ga1ce60f5416d4f75586836c1429c37149", null ],
    [ "ncxml_reply_data_ns", "d9/de5/messages__xml_8h.html#ga3647f5a4bb6d8827a613a6b214d45581", null ],
    [ "ncxml_reply_dump", "d9/de5/messages__xml_8h.html#ga68ec8a0daf54f584339924bca5b5a682", null ],
    [ "ncxml_reply_get_data", "d9/de5/messages__xml_8h.html#ga7878bc6bc6b6d1ca002044d7edf85943", null ],
    [ "ncxml_rpc_build", "d9/de5/messages__xml_8h.html#gaa6bcfc7c3e217e1b64c63bd674af4d8e", null ],
    [ "ncxml_rpc_copyconfig", "d9/de5/messages__xml_8h.html#gae7ab635ff3bb76089e372f3d22ebaf3c", null ],
    [ "ncxml_rpc_dump", "d9/de5/messages__xml_8h.html#ga9f27fbe1879115a07d7b3ae8bf6be9e6", null ],
    [ "ncxml_rpc_editconfig", "d9/de5/messages__xml_8h.html#gaf75f595f932fa0f075d633015829a85c", null ],
    [ "ncxml_rpc_generic", "d9/de5/messages__xml_8h.html#gaad5d888e8c4a07a5f59b31555f7413bb", null ],
    [ "ncxml_rpc_get_config", "d9/de5/messages__xml_8h.html#ga16f3dd2aaa13922eae37551179913b18", null ],
    [ "ncxml_rpc_get_op_content", "d9/de5/messages__xml_8h.html#ga78cb3e4ae4050de932cb9e705316ce53", null ]
];