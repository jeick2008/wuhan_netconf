var structtransapi__rpc__callbacks =
[
    [ "callbacks", "d0/df8/structtransapi__rpc__callbacks.html#a0ad28c1d0d3518ca0b3d631a20eaf48d", null ],
    [ "callbacks_count", "d0/df8/structtransapi__rpc__callbacks.html#a853d73f0f495147dba4842e9f860d1f0", null ],
    [ "func", "d0/df8/structtransapi__rpc__callbacks.html#a4e198e0f385cc9d713aa918597858fbb", null ],
    [ "name", "d0/df8/structtransapi__rpc__callbacks.html#a5ac083a645d964373f022d03df4849c8", null ]
];