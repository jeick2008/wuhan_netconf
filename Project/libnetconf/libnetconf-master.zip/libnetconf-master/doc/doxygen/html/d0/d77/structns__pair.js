var structns__pair =
[
    [ "href", "d0/d77/structns__pair.html#a824af08b85c784da51d23d04342ab593", null ],
    [ "prefix", "d0/d77/structns__pair.html#a5b41c5ae4505891e6c53e26df197e02b", null ]
];