var group__notifications__xml =
[
    [ "ncxmlntf_event_new", "db/dae/group__notifications__xml.html#ga21824f1e804eed5f8907eefdd9d03a85", null ],
    [ "ncxmlntf_notif_create", "db/dae/group__notifications__xml.html#gae1d3152a18bb5d030f9d42d62658986c", null ],
    [ "ncxmlntf_notif_get_content", "db/dae/group__notifications__xml.html#ga26fc8f89287a14cc1da067d9aeb92fdf", null ]
];