var modules =
[
    [ "General functions", "d3/d35/group__gen_a_p_i.html", "d3/d35/group__gen_a_p_i" ],
    [ "NETCONF Session", "db/d52/group__session.html", "db/d52/group__session" ],
    [ "Call Home", "db/de7/group__callhome.html", "db/de7/group__callhome" ],
    [ "NETCONF rpc", "db/de9/group__rpc.html", "db/de9/group__rpc" ],
    [ "NETCONF rpc-reply", "d0/de2/group__reply.html", "d0/de2/group__reply" ],
    [ "Datastore operations", "db/d67/group__store.html", "db/d67/group__store" ],
    [ "With-defaults capability", "d1/df7/group__withdefaults.html", "d1/df7/group__withdefaults" ],
    [ "URL capability", "d5/d7d/group__url.html", "d5/d7d/group__url" ],
    [ "NETCONF Event Notifications", "da/d54/group__notifications.html", "da/d54/group__notifications" ],
    [ "Transaction API", "d8/d55/group__transapi.html", "d8/d55/group__transapi" ],
    [ "NETCONF rpc (libxml2)", "d7/dda/group__rpc__xml.html", "d7/dda/group__rpc__xml" ],
    [ "NETCONF rpc-reply (libxml2)", "d8/d73/group__reply__xml.html", "d8/d73/group__reply__xml" ],
    [ "NETCONF Event Notifications (libxml2)", "db/dae/group__notifications__xml.html", "db/dae/group__notifications__xml" ],
    [ "NETCONF over TLS", "db/db4/group__tls.html", "db/db4/group__tls" ]
];