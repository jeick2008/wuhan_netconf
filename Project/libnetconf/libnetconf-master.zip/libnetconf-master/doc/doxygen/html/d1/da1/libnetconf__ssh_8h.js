var libnetconf__ssh_8h =
[
    [ "NC_SSH_AUTH_TYPE", "d1/da1/libnetconf__ssh_8h.html#gad9081cbe1edde22e8612e07ba4c3be10", [
      [ "NC_SSH_AUTH_PUBLIC_KEYS", "d1/da1/libnetconf__ssh_8h.html#ggad9081cbe1edde22e8612e07ba4c3be10a33741824ba5809f9e29b99d68e1bb6a3", null ],
      [ "NC_SSH_AUTH_PASSWORD", "d1/da1/libnetconf__ssh_8h.html#ggad9081cbe1edde22e8612e07ba4c3be10a57ebf13ab1802ab10650d4c4c77e7eef", null ],
      [ "NC_SSH_AUTH_INTERACTIVE", "d1/da1/libnetconf__ssh_8h.html#ggad9081cbe1edde22e8612e07ba4c3be10a497854e455f81123847c1ba089c40158", null ]
    ] ],
    [ "nc_session_accept_libssh_channel", "d1/da1/libnetconf__ssh_8h.html#a159471d23a8253670ae176615f16965b", null ],
    [ "nc_session_connect_libssh_sess", "d1/da1/libnetconf__ssh_8h.html#gae721f4b40b7e16a2fe22161378ad9031", null ],
    [ "nc_ssh_pref", "d1/da1/libnetconf__ssh_8h.html#ga13119fdaa84544bf254bdb35ffdf83e0", null ]
];