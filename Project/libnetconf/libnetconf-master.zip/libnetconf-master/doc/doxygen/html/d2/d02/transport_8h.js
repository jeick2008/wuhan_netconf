var transport_8h =
[
    [ "nc_session_accept", "d2/d02/transport_8h.html#gad0e758dfee764ae9c2a032e0151c6707", null ],
    [ "nc_session_accept_inout", "d2/d02/transport_8h.html#ga4d2da6dc354779dbd7a745147fa40457", null ],
    [ "nc_session_accept_username", "d2/d02/transport_8h.html#ga7ee207cac84fd5cd82419af41e14c06f", null ],
    [ "nc_session_connect", "d2/d02/transport_8h.html#gae3858d998d19cb2fb700b15fdf602f23", null ],
    [ "nc_session_connect_channel", "d2/d02/transport_8h.html#ga7d9e0f17bb4ca5b35c8343db59955060", null ],
    [ "nc_session_connect_inout", "d2/d02/transport_8h.html#gacaf7b465963605a29f25c3a36df378a6", null ],
    [ "nc_session_transport", "d2/d02/transport_8h.html#ga6e125c035cdebae8c49ff962866c0806", null ]
];